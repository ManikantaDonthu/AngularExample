import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  thirdPartyArr: any[] = [];
  ctrArr: any[] = [];

  constructor() {
  	this.thirdPartyArr = [{
  		rctid: "ABP004",
  		name: "mani",
  		customName: "SOCGEN",
  		ctr: "014",
  		postalCode: "500005",
  		region: "Bangalore",
  		validatity: "Y",
  		rating: "2+"
  	},{
  		rctid: "ABP008",
  		name: "manii",
  		customName: "SOCGEN1",
  		ctr: "018",
  		postalCode: "500066",
  		region: "Bangalore",
  		validatity: "N",
  		rating: "2+"
  	},{
  		rctid: "ABP009",
  		name: "maniii",
  		customName: "SOCGEN2",
  		ctr: "016",
  		postalCode: "500063",
  		region: "Bangalore",
  		validatity: "N",
  		rating: "3+"
  	},{
  		rctid: "ABP011",
  		name: "maniii4",
  		customName: "SOCGEN3",
  		ctr: "016",
  		postalCode: "500069",
  		region: "Bangalore",
  		validatity: "Y",
  		rating: "4+"
  	}];

  	this.ctrArr = [{
  		label: "Select CTR", 
  		value: null
  	},{
  		label: "014", 
  		value: "014"
  	},{
  		label: "018", 
  		value: "018"
  	},{
  		label: "016", 
  		value: "016"
  	}];
  }

  deleteObj(obj, index:number){
    console.log(obj);
    console.log("here",index);
    this.thirdPartyArr = this.thirdPartyArr.filter(item => item.rctid !== obj.rctid);
  }
}
