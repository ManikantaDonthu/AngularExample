"use strict";
var Observable_1 = require('../../Observable');
var onErrorResumeNext_1 = require('../../observable/onErrorResumeNext');
Observable_1.Observable.onErrorResumeNext = onErrorResumeNext_1.onErrorResumeNext;
//# sourceMappingURL=onErrorResumeNext.js.map