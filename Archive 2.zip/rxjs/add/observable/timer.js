"use strict";
var Observable_1 = require('../../Observable');
var timer_1 = require('../../observable/timer');
Observable_1.Observable.timer = timer_1.timer;
//# sourceMappingURL=timer.js.map