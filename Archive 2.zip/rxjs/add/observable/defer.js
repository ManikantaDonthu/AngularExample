"use strict";
var Observable_1 = require('../../Observable');
var defer_1 = require('../../observable/defer');
Observable_1.Observable.defer = defer_1.defer;
//# sourceMappingURL=defer.js.map