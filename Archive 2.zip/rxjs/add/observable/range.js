"use strict";
var Observable_1 = require('../../Observable');
var range_1 = require('../../observable/range');
Observable_1.Observable.range = range_1.range;
//# sourceMappingURL=range.js.map