module.exports = require("./lib/_stream_duplex.js")
