# Metadata Reflection API

The spec has moved to https://rbuckton.github.io/reflect-metadata/