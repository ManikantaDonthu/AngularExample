export { bootstrapItem, insertImport, addPathToRoutes, addItemsToRouteProperties, confirmComponentExport, resolveComponentPath, applyChanges } from '../lib/ast-tools';
