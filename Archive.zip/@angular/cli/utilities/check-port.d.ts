export declare function checkPort(port: number, host: string, basePort?: number): Promise<number>;
