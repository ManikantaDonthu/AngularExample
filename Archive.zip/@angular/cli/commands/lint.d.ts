export interface LintCommandOptions {
    fix?: boolean;
    typeCheck?: boolean;
    format?: string;
    force?: boolean;
}
declare const _default: any;
export default _default;
