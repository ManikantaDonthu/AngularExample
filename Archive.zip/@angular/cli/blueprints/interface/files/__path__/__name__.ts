export interface <%= prefix %><%= classifiedModuleName %> {
}
