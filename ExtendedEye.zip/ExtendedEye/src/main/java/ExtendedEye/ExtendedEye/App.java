package ExtendedEye.ExtendedEye;

import java.io.File;

/**
 * Hello world!
 *
 */
public class App 
{
	
	private static final File FILE_NAME = new File(System.getProperty("user.home")+"/Downloads/input.pdf");
	private static final File FILE_OUTPUT_NAME = new File(System.getProperty("user.home")+"/Downloads/PDFOutput.txt");

	public static void main( String[] args )
    {
    	ConvertPDFtoText.extractTextFromPDF(FILE_NAME, FILE_OUTPUT_NAME, true);
    }
}
