package com.dzone;

import java.io.File;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class AlertSearch {

	private static final String LUCENE_QUERY = "(entity:alert AND id:38882)";
	private static final int MAX_HITS = 100;

	public static void main(String[] args) throws Exception {
		File indexDir = new File("E:\\pfs77_1\\jboss-5.1.0.GA\\server\\default\\search_index");
		String query = LUCENE_QUERY;
		AlertSearch searcher = new AlertSearch();
		searcher.searchIndex(indexDir, query);
	}

	private void searchIndex(File indexDir, String queryStr) throws Exception {
		Directory directory = FSDirectory.open(indexDir);
		MultiFieldQueryParser queryParser = new MultiFieldQueryParser(Version.LUCENE_47,
				new String[] { "partyname" }, new StandardAnalyzer(Version.LUCENE_47));
		
		IndexReader reader = IndexReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);
		/*queryParser.setPhraseSlop(0);
		queryParser.setLowercaseExpandedTerms(true);*/
		Query query = queryParser.parse(queryStr);
		TopDocs topDocs = searcher.search(query, MAX_HITS);
		ScoreDoc[] hits = topDocs.scoreDocs;
		System.out.println(hits.length + " Record(s) Found");
		for (int i = 0; i < hits.length; i++) {
			int docId = hits[i].doc;
			Document d = searcher.doc(docId);
			System.out.println(d.get("partyname") +" " +d.get("providertype"));
		}
		if (hits.length == 0) {
			System.out.println("No Data Founds ");
		}
	}

}
