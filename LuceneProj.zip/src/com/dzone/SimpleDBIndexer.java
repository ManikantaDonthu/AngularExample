
package com.dzone;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.document.DateTools.Resolution;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class SimpleDBIndexer {

	public static final String INDEX_DIR = "E:\\Servers\\EN_INT_PFS_792_7\\jboss-5.1.0.GA\\server\\default\\search_index\\";
	private static final String JDBC_DRIVER = "com.jnetdirect.jsql.JSQLDriver";
	private static final String CONNECTION_URL = "jdbc:JSQLConnect://dhi-partha:1433/databaseName=LuceneTestDb";
	private static final String USER_NAME = "sa";
	private static final String PASSWORD = "dhi123$";
	private static final String QUERY1 = "select id,name from Person";
	private static final String QUERY2 = "select id,Name from Gender";

	public static void main(String[] args) throws Exception {
		File indexDir = new File(INDEX_DIR);
		SimpleDBIndexer indexer = new SimpleDBIndexer();
		try {
			Class.forName(JDBC_DRIVER).newInstance();
			Connection conn = DriverManager.getConnection(CONNECTION_URL, USER_NAME, PASSWORD);
			SimpleAnalyzer analyzer = new SimpleAnalyzer(Version.LUCENE_47);
			IndexWriterConfig indexWriterConfig = new IndexWriterConfig(Version.LUCENE_47, analyzer);
			IndexWriter indexWriter = new IndexWriter(FSDirectory.open(indexDir), indexWriterConfig);
			System.out.println("Indexing to directory '" + indexDir + "'...");
			int indexedDocumentCount1 = indexer.indexDocs1(indexWriter, conn);
			int indexedDocumentCount2 = indexer.indexDocs2(indexWriter, conn);
			indexWriter.close();
			System.out.println(indexedDocumentCount1 + " records have been indexed successfully");
			System.out.println(indexedDocumentCount2 + " records have been indexed successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	int indexDocs1(IndexWriter writer, Connection conn) throws Exception {
		String sql = QUERY1;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		int i = 0;
		while (rs.next()) {
			Document d = new Document();
			d.add(new Field("PersonName", rs.getString(2), Field.Store.YES, Field.Index.ANALYZED));
			d.add(new Field("PersonId", rs.getString(1), Field.Store.YES, Field.Index.ANALYZED));
			
			writer.addDocument(d);
			i++;
		}
		rs.close();
		return i;
	}
	
	int indexDocs2(IndexWriter writer, Connection conn) throws Exception {
		String sql = QUERY2;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		int i = 0;
		while (rs.next()) {
			Document d = new Document();
			d.add(new Field("GenderName", rs.getString(2), Field.Store.YES, Field.Index.ANALYZED));
			d.add(new Field("GenderId", rs.getString(1), Field.Store.YES, Field.Index.ANALYZED));
			
			writer.addDocument(d);
			i++;
		}
		rs.close();
		return i;
	}

}
