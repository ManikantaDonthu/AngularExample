0.4.3 / 2017-04-15
==================

	* Docs - Document new features. #26

0.4.2 / 2017-04-12
==================

	* Chore - Fix readme link formatting. #25

0.4.1 / 2017-04-05
==================

	* Chore - Note that cheap source maps don't work with the plugin. #22

0.4.0 / 2017-03-30
==================

	* Chore - Update to *webpack-sources* ^0.2.3. #22

0.3.1 / 2017-03-22
==================

	* Chore - Improve readme wording. #19

0.3.0 / 2017-03-04
==================

	* Chore - Update to UglifyJS 2.8.0 API internally. #16

0.2.2 / 2017-03-02
==================

	* Bug fix - Fix `postinstall` script. Now it works if you install the packagre from repository in Node 6+.

0.2.1 / 2017-02-20
==================

	* Docs - Fix typo at readme. #10

0.2.0 / 2017-02-19
==================

	* Feature - Allow to extract comments to separate file [webpack/webpack#4134](https://github.com/webpack/webpack/pull/4134)
	* Feature - Allow to supress uglifyjs warnings [webpack/webpack#4200](https://github.com/webpack/webpack/pull/4200)
	* Chore - Use `const` where applicable [1d78f99](https://github.com/webpack/webpack/commit/1d78f990a6af1a5b85e45b345b4f7861b03bb12b)
	* Chore - Avoid reassigning stream with different value [92364dc](https://github.com/webpack/webpack/commit/92364dc0f72ad8c3ac0bdc74e46766658086d83a)
	* Chore - Avoid reassigning files with different value [104398f](https://github.com/webpack/webpack/commit/104398f87a707a601427e666ed318d2338e8a003)

0.1.5 / 2017-02-15
==================

	* Docs - Add `extractComments` documentation. #7

0.1.4 / 2017-02-06
==================

	* Docs - Simplify example.

0.1.3 / 2017-02-02
==================

	* Docs - Fix table syntax. #6

0.1.2 / 2017-01-25
==================

	* Docs - Add note about the plugin embedded to webpack.

0.1.1 / 2017-01-25
==================

	* Docs - Update installation instructions.

0.1.0 / 2017-01-24
==================

	* Initial port from webpack source.
